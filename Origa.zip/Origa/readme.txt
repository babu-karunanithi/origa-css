Database credentials to verify the operation:
clientUrl = "mongodb+srv://babu:test@babuk.p7n6q.mongodb.net/myFirstDatabase"
password   = test
DatabaseName= myFirstDatabase;
CollectionNames ={ User, Order };
Steps to connect MongoDB Compass:
	1. launch MongoDB Compass
	2. provide clientUrl and password

Backend (Nodejs-express server):
Steps to connect:
	1. cd backend
        2. npm install
	3. node app.js
	4. hit localhost:5000


Frontend (Angular application):
Steps to connect:
	1. cd frontend
        2. npm install 
	3. npm start
	4. hit localhost:4200